﻿---
title: 증상별 경혈 지도
description: 불면·소화불량·요통·비염의 대표 경혈을 증상과 변증에 따라 탐색합니다.
tags: [경혈, 침구, 임상지식망]
status: 검토완료
last_reviewed: 2026-08-19
---
# 증상별 경혈 지도

## 불면
```text
불면
├─ 신문 HT7
├─ 삼음교 SP6
├─ 내관 PC6
└─ 백회 GV20
```

## 소화불량
```text
소화불량
├─ 족삼리 ST36
├─ 내관 PC6
└─ 중완 CV12
```

## 요통
```text
요통
├─ 신수 BL23
├─ 위중 BL40
└─ 국소 아시혈
```

## 비염
```text
비염
├─ 합곡 LI4
└─ 족삼리 ST36 등 원위 배혈
```

이 표는 대표적인 연결을 보여주는 지식지도이며 실제 침구치료는 증후·부위·경락과 환자의 상태에 따라 배혈이 달라진다.

→ [질환→치료 통합 지도](../network/condition-to-treatment-map.md)

<!-- MINSEONG_ONE_SHOT_FIX_V2 -->
## 관련 핵심 문서

- [침구·치료 한눈에 보기](../acupuncture-integrated/index.md)
- [증상으로 침구치료 찾기](../acupuncture-integrated/by-symptom.md)
- [침구 안전·위험신호](../acupuncture-integrated/safety.md)

