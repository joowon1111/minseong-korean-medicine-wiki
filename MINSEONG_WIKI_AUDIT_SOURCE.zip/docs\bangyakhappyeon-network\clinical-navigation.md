﻿---
title: 방약합편 처방 탐색법
description: 방약합편 처방 탐색법을 방약합편의 본초·처방·임상 탐색 구조로 정리합니다.
tags: [방약합편, 손익본초, 약성가, 의방활투]
status: 검토완료
last_reviewed: 2026-08-20
---
# 방약합편 처방 탐색법

방약합편은 본초와 처방을 빠르게 왕복하며 탐색하는 데 강점이 있다.

```text
병증 파악
 ↓
치료 방향 판단
 ↓
보·화·공
 ↓
상통·중통·하통
 ↓
후보 처방
 ↓
구성 본초·약성 확인
 ↓
주치·가감 검토
```

핵심은 **본초 ↔ 치법 ↔ 처방**을 연결해서 보는 것이다.

<!-- MINSEONG_ONE_SHOT_FIX_V2 -->
## 관련 핵심 문서

- [한의학 고전 읽기](../classics-network/reading-path.md)
- [주요 고전 비교](../classics-network/comparison.md)
- [근거와 출처](../ai/evidence-map.md)

