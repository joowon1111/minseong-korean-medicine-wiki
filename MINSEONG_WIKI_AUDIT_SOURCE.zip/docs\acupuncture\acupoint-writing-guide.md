﻿---
title: 경혈 문서 작성 원칙
description: 경혈 문서의 위치·전통적 효능·현대 연구·안전성 표준 작성 형식을 정리합니다.
tags: [침구, 운영, 경혈]
status: 검토완료
last_reviewed: 2026-08-19
---

# 경혈 문서 작성 원칙

민성 한의학 아카이브의 경혈 문서는 가능한 한 동일한 형식으로 작성한다.

## 기본 구성
1. **표준 코드** — 예: ST36, PC6
2. **한글명·한자명·영문 표기**
3. **소속 경맥**
4. **표준 위치**
5. **전통적 효능과 주치**
6. **대표적인 임상 활용**
7. **현대 임상·기전 연구**
8. **안전성과 시술 시 주의**
9. **관련 장부·경락·질환 지식망**

## 위치 기준
경혈 위치는 국제적으로 표준화된 위치 체계를 우선 사용하고, 고전적 위치 설명이 필요한 경우 별도로 구분한다.

## 연구 인용
현대 연구를 인용할 때는 가능하면 RCT·systematic review·meta-analysis의 연구유형과 PMID·DOI를 함께 제시한다.

## 표현 원칙
특정 경혈 하나가 특정 질환을 단독으로 치료한다고 단정하지 않는다. 실제 침구치료는 경락·장부·변증과 국소 상태를 함께 고려해 배혈한다.

→ [주요 경혈](key-acupoints.md)  
→ [침구 임상 지식망](../network/acupuncture-clinical-map.md)

<!-- MINSEONG_ONE_SHOT_FIX_V2 -->
## 관련 핵심 문서

- [침구·치료 한눈에 보기](../acupuncture-integrated/index.md)
- [증상으로 침구치료 찾기](../acupuncture-integrated/by-symptom.md)
- [침구 안전·위험신호](../acupuncture-integrated/safety.md)

