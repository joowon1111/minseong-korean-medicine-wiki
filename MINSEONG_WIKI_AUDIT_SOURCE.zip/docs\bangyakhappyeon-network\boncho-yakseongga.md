﻿---
title: 손익본초와 약성가
description: 손익본초와 약성가을 방약합편의 본초·처방·임상 탐색 구조로 정리합니다.
tags: [방약합편, 손익본초, 약성가, 의방활투]
status: 검토완료
last_reviewed: 2026-08-20
---
# 손익본초와 약성가

손익본초와 약성가는 개별 본초의 성질과 효능을 압축적으로 파악하고 처방 구성의 의미를 이해하는 데 도움을 준다.

```text
본초
 ↓
성미·효능
 ↓
약성가
 ↓
처방 속 역할
```

본초와 방제를 따로 외우기보다 **약물의 성질 → 배합 → 처방의 치료 방향**으로 연결해 볼 수 있다.

<!-- MINSEONG_ONE_SHOT_FIX_V2 -->
## 관련 핵심 문서

- [한의학 고전 읽기](../classics-network/reading-path.md)
- [주요 고전 비교](../classics-network/comparison.md)
- [근거와 출처](../ai/evidence-map.md)

